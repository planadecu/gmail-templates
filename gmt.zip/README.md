Gmail Templates and Snippet manager Chrome Extension
====================================================

GNUv2 Licence - 2013-2014, Jordi Planadecursach
http://www.rourevell.com 

====================================================

Tired of sending always the same type of mails. Tired of copy pasting mails from word, drive, dropbox and lose styles, layouts and colours?

Gmail Tempalte and snippets manager allows you to manage a list of predefined templates and insert them directly to your "compose mail" view.

A powerful templating engine is provided so you don't have to replace the fields inside the template manually. Popups are going to ask you what data do you want to insert.

Supports gmail in several languages:
- English
- Spanish
- French
- Deutch
- Catalan

===============

Donate bitcoins to 1P6WR8KJeUmJZLPNXXyoKTEgMQvn3k8jd7 if you like.